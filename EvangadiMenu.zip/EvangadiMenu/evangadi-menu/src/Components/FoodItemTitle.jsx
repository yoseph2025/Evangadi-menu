import { Component } from 'react';
import '../commonResource/style.css'
class FoodItemTitle extends Component {
  render() {
    return (
      <div className="all-container">
          <header className="title">
            <h1>Evangadi Menu</h1>
            <div></div>
          </header>
      </div>
    );
  }
}

export default FoodItemTitle;

